#ifndef tcp_client_h
#define tcp_client_h

int create_tcp_client_fd();

#endif
