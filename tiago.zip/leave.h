#ifndef leave_h
#define leave_h

void leave(char *regIP, char *regUDP, t_node_info *my_node);

#endif