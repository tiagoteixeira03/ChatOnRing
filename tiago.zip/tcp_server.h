#ifndef tcp_server_h
#define tcp_server_h

int create_tcp_server_fd(t_node_info *my_node);

#endif
