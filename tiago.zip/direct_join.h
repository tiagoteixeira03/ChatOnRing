
#ifndef direct_join_h
#define direct_join_h

void direct_join(t_node_info *my_node);
void receive_message(t_node_info *my_node);

#endif